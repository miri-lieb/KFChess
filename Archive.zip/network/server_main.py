import asyncio
import logging

from network.server import create_local_server
from network.web_server import start_web_server


async def _run_server():
    server = await create_local_server()
    async with server:
        print(f"Local WebSocket server listening on ws://{server.host}:{server.port}")
        try:
            web = start_web_server()
            print(f"Web GUI available at http://localhost:{web.server_address[1]}")
        except OSError as exc:
            print(f"Web GUI server failed to start: {exc}")
        await asyncio.Future()


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    try:
        asyncio.run(_run_server())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
