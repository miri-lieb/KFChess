import logging
import os
import threading
from functools import partial
from http.server import HTTPServer, SimpleHTTPRequestHandler

logger = logging.getLogger(__name__)

WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web")

MIME_TYPES = {
    ".html": "text/html",
    ".css": "text/css",
    ".js": "application/javascript",
    ".json": "application/json",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
}


class KFChessHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, directory=None, **kwargs):
        super().__init__(*args, directory=directory, **kwargs)

    def guess_type(self, path):
        ext = os.path.splitext(path)[1].lower()
        return MIME_TYPES.get(ext, super().guess_type(path))

    def log_message(self, format, *args):
        logger.debug("HTTP %s", format % args)


def start_web_server(host: str = "0.0.0.0", port: int = 8080) -> HTTPServer:
    handler = partial(KFChessHandler, directory=WEB_DIR)
    server = HTTPServer((host, port), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    logger.info("Web GUI serving at http://%s:%d", host, port)
    return server
