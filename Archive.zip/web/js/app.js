(function () {
  'use strict';

  /* ================================================================
     CONSTANTS
     ================================================================ */
  const WS_PORT = 8765;
  const CELL_SIZE = 75;
  const BOARD_SIZE = CELL_SIZE * 8;
  const RECONNECT_DELAY = 2000;
  const RECONNECT_MAX = 10000;

  const PIECE_UNICODE = {
    white: { king: '\u2654', queen: '\u2655', rook: '\u2656', bishop: '\u2657', knight: '\u2658', pawn: '\u2659' },
    black: { king: '\u265A', queen: '\u265B', rook: '\u265C', bishop: '\u265D', knight: '\u265E', pawn: '\u265F' },
  };

  const LIGHT_SQ = '#F0D9B5';
  const DARK_SQ = '#B58863';
  const SELECTED_COLOR = 'rgba(255, 235, 59, 0.45)';
  const LEGAL_MOVE_DOT = 'rgba(100, 181, 246, 0.5)';

  /* ================================================================
     STATE
     ================================================================ */
  let ws = null;
  let reconnectTimer = null;
  let reconnectDelay = RECONNECT_DELAY;
  let messageHandlers = [];

  let session = {
    username: null,
    role: null,
    color: null,
    elo: null,
    roomId: null,
  };

  let game = {
    board: null,       // { width, height, pieces: [{id, color, kind, cell:{row,col}}] }
    players: {},       // { white: {name, score, ...}, black: {...} }
    motions: [],
    elapsedTimeMs: 0,
    gameOver: false,
    winnerColor: null,
    selected: null,    // { row, col } or null
    moveLog: [],       // [{color, time, notation}]
    animationTick: 0,
  };

  let gameAnimFrame = null;

  /* ================================================================
     WEBSOCKET
     ================================================================ */
  function connectWS() {
    const uri = 'ws://' + location.hostname + ':' + WS_PORT;
    ws = new WebSocket(uri);

    ws.onopen = function () {
      reconnectDelay = RECONNECT_DELAY;
      updateAuthStatus(false);
    };

    ws.onclose = function () {
      updateAuthStatus(true);
      scheduleReconnect();
    };

    ws.onerror = function () {
      ws.close();
    };

    ws.onmessage = function (evt) {
      let msg;
      try { msg = JSON.parse(evt.data); } catch (e) { return; }
      dispatchMessage(msg);
    };
  }

  function scheduleReconnect() {
    if (reconnectTimer) return;
    reconnectTimer = setTimeout(function () {
      reconnectTimer = null;
      connectWS();
    }, reconnectDelay);
    reconnectDelay = Math.min(reconnectDelay * 1.5, RECONNECT_MAX);
  }

  function wsSend(obj) {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(obj));
    }
  }

  function dispatchMessage(msg) {
    for (let i = 0; i < messageHandlers.length; i++) {
      messageHandlers[i](msg);
    }
  }

  function onMessage(handler) {
    messageHandlers.push(handler);
  }

  /* ================================================================
     SCREEN MANAGEMENT
     ================================================================ */
  function showScreen(id) {
    document.querySelectorAll('.screen').forEach(function (s) {
      s.classList.remove('active');
    });
    document.getElementById(id).classList.add('active');
  }

  /* ================================================================
     AUTH
     ================================================================ */
  function setupAuth() {
    var tabs = document.querySelectorAll('.auth-tab');
    var loginForm = document.getElementById('login-form');
    var registerForm = document.getElementById('register-form');

    tabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        tabs.forEach(function (t) { t.classList.remove('active'); });
        tab.classList.add('active');
        var isLogin = tab.dataset.tab === 'login';
        loginForm.classList.toggle('hidden', !isLogin);
        registerForm.classList.toggle('hidden', isLogin);
        hideAuthMessage();
      });
    });

    loginForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var username = document.getElementById('login-username').value.trim();
      var password = document.getElementById('login-password').value;
      if (!username || !password) {
        showAuthMessage('Please fill in all fields', 'error');
        return;
      }
      wsSend({ type: 'login', username: username, password: password, register: false });
    });

    registerForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var username = document.getElementById('reg-username').value.trim();
      var password = document.getElementById('reg-password').value;
      var password2 = document.getElementById('reg-password2').value;
      if (!username || !password) {
        showAuthMessage('Please fill in all fields', 'error');
        return;
      }
      if (password !== password2) {
        showAuthMessage('Passwords do not match', 'error');
        return;
      }
      wsSend({ type: 'login', username: username, password: password, register: true });
    });
  }

  function showAuthMessage(text, type) {
    var el = document.getElementById('auth-message');
    el.textContent = text;
    el.className = 'message ' + type;
  }

  function hideAuthMessage() {
    var el = document.getElementById('auth-message');
    el.className = 'message hidden';
  }

  function updateAuthStatus(connecting) {
    var el = document.getElementById('auth-status');
    el.classList.toggle('hidden', !connecting);
  }

  /* ================================================================
     LOBBY
     ================================================================ */
  function setupLobby() {
    document.getElementById('create-room-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var name = document.getElementById('room-name').value.trim();
      if (!name) return;
      wsSend({ type: 'create_room', username: session.username, room_name: name });
      showLobbyMessage('create-room-message', 'Creating room...', 'success');
    });

    document.getElementById('refresh-rooms-btn').addEventListener('click', function () {
      wsSend({ type: 'list_rooms' });
    });

    document.getElementById('join-id-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var id = document.getElementById('join-room-id').value.trim().toUpperCase();
      if (!id) return;
      wsSend({ type: 'join_room', username: session.username, password: '', room_id: id });
      showLobbyMessage('join-room-message', 'Joining room...', 'success');
    });

    document.getElementById('logout-btn').addEventListener('click', function () {
      session = { username: null, role: null, color: null, elo: null, roomId: null };
      if (ws) ws.close();
      showScreen('auth-screen');
    });
  }

  function enterLobby() {
    showScreen('lobby-screen');
    document.getElementById('lobby-username').textContent = session.username;
    document.getElementById('lobby-elo').textContent = 'ELO: ' + (session.elo || '?');
    document.getElementById('room-name').value = '';
    document.getElementById('join-room-id').value = '';
    hideLobbyMessages();
    wsSend({ type: 'list_rooms' });
  }

  function showLobbyMessage(id, text, type) {
    var el = document.getElementById(id);
    el.textContent = text;
    el.className = 'message ' + type;
  }

  function hideLobbyMessages() {
    document.getElementById('create-room-message').className = 'message hidden';
    document.getElementById('join-room-message').className = 'message hidden';
  }

  function populateRoomList(rooms) {
    var tbody = document.getElementById('rooms-tbody');
    tbody.innerHTML = '';
    if (!rooms || rooms.length === 0) {
      tbody.innerHTML = '<tr class="empty-row"><td colspan="5">No rooms available. Create one!</td></tr>';
      return;
    }
    rooms.forEach(function (room) {
      var playerCount = room.players || 0;
      var statusClass = playerCount < 2 ? 'waiting' : 'full';
      var statusText = playerCount < 2 ? 'Waiting' : 'Full';
      if (room.status === 'playing') {
        statusClass = 'playing';
        statusText = 'In Progress';
      }
      var tr = document.createElement('tr');
      tr.innerHTML =
        '<td>' + escapeHtml(room.name) + '</td>' +
        '<td>' + escapeHtml(room.creator) + '</td>' +
        '<td>' + playerCount + ' / 2</td>' +
        '<td><span class="room-status ' + statusClass + '">' + statusText + '</span></td>' +
        '<td>' + (playerCount < 2
          ? '<button class="btn btn-sm btn-primary join-room-btn" data-room-id="' + escapeHtml(room.id) + '">Join</button>'
          : '') + '</td>';
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.join-room-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var roomId = btn.dataset.roomId;
        wsSend({ type: 'join_room', username: session.username, password: '', room_id: roomId });
        showLobbyMessage('join-room-message', 'Joining room ' + roomId + '...', 'success');
      });
    });
  }

  /* ================================================================
     GAME
     ================================================================ */
  function setupGame() {
    var canvas = document.getElementById('chess-canvas');
    canvas.width = BOARD_SIZE;
    canvas.height = BOARD_SIZE;

    canvas.addEventListener('click', onBoardClick);

    document.getElementById('leave-room-btn').addEventListener('click', function () {
      leaveRoom();
    });

    document.getElementById('back-to-lobby-btn').addEventListener('click', function () {
      document.getElementById('game-over-overlay').classList.add('hidden');
      enterLobby();
    });

    document.getElementById('copy-room-id').addEventListener('click', function () {
      var id = session.roomId;
      if (id && navigator.clipboard) {
        navigator.clipboard.writeText(id);
      }
    });
  }

  function enterGame(payload) {
    session.roomId = payload.room_id || null;
    session.role = payload.role;
    session.color = payload.color;
    session.elo = payload.elo;

    if (payload.snapshot) {
      applySnapshot(payload.snapshot);
    }

    game.selected = null;
    game.moveLog = [];
    game.gameOver = false;
    game.winnerColor = null;

    showScreen('game-screen');
    updateGameUI();
    startGameLoop();
  }

  function leaveRoom() {
    stopGameLoop();
    session.roomId = null;
    session.role = null;
    session.color = null;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.close();
    }
    enterLobby();
  }

  function updateGameUI() {
    var bp = game.players.black || {};
    var wp = game.players.white || {};

    document.getElementById('player-black-name').textContent = bp.name || 'Black';
    document.getElementById('player-black-meta').textContent = bp.name ? ('ELO: ' + (bp.elo || '?')) : 'Waiting...';
    document.getElementById('player-black-score').textContent = bp.score || 0;

    document.getElementById('player-white-name').textContent = wp.name || 'White';
    document.getElementById('player-white-meta').textContent = wp.name ? ('ELO: ' + (wp.elo || '?')) : 'Waiting...';
    document.getElementById('player-white-score').textContent = wp.score || 0;

    document.getElementById('game-room-id').textContent = session.roomId || '-';
    document.getElementById('your-role-text').textContent = session.role || '-';

    var seconds = Math.floor(game.elapsedTimeMs / 1000);
    var mins = Math.floor(seconds / 60);
    var secs = seconds % 60;
    document.getElementById('game-timer').textContent =
      String(mins).padStart(2, '0') + ':' + String(secs).padStart(2, '0');

    if (game.gameOver) {
      var overlay = document.getElementById('game-over-overlay');
      overlay.classList.remove('hidden');
      var winner = game.winnerColor ? game.winnerColor.charAt(0).toUpperCase() + game.winnerColor.slice(1) : 'Draw';
      document.getElementById('game-over-title').textContent = 'Game Over';
      document.getElementById('game-over-text').textContent =
        game.winnerColor ? winner + ' wins!' : 'The game is a draw.';
    }

    updateMoveLog();
  }

  function updateMoveLog() {
    var el = document.getElementById('move-log');
    el.innerHTML = '';
    game.moveLog.forEach(function (m) {
      var div = document.createElement('div');
      div.className = 'move-entry';
      div.innerHTML = '<span class="move-time">' + escapeHtml(m.time) + '</span>' +
        '<span class="move-text">' + escapeHtml(m.notation) + '</span>';
      el.appendChild(div);
    });
    el.scrollTop = el.scrollHeight;
  }

  /* ================================================================
     SNAPSHOT / MESSAGE HANDLING
     ================================================================ */
  function applySnapshot(snap) {
    game.board = snap.board;
    game.players = snap.players || {};
    game.motions = snap.active_motions || [];
    game.elapsedTimeMs = snap.elapsed_time_ms || 0;
    game.gameOver = snap.game_over || false;
    game.winnerColor = snap.winner_color || null;
  }

  function handleServerMessage(msg) {
    switch (msg.type) {
      case 'login_ack':
        handleLoginAck(msg.payload);
        break;
      case 'error':
        handleError(msg);
        break;
      case 'room_created':
        handleRoomJoined(msg.payload);
        break;
      case 'room_joined':
        handleRoomJoined(msg.payload);
        break;
      case 'rooms_list':
        populateRoomList(msg.payload.rooms);
        break;
      case 'snapshot':
        handleSnapshotMsg(msg.payload);
        break;
      case 'move_requested':
        handleMoveRequested(msg.payload);
        break;
      case 'move_resolved':
        handleMoveResolved(msg.payload);
        break;
      case 'game_over':
        handleGameOverMsg(msg.payload);
        break;
      case 'player_joined':
        handlePlayerJoined(msg.payload);
        break;
      case 'player_left':
        handlePlayerLeft(msg.payload);
        break;
      case 'move_ack':
        handleMoveAck(msg.payload);
        break;
    }
  }

  function handleLoginAck(payload) {
    session.username = payload.username;
    session.role = payload.role;
    session.color = payload.color;
    session.elo = payload.elo;
    session.roomId = null;
    enterLobby();
  }

  function handleError(msg) {
    var reason = msg.reason || 'unknown_error';
    var friendly = formatReason(reason);

    if (document.getElementById('auth-screen').classList.contains('active')) {
      showAuthMessage(friendly, 'error');
    } else if (document.getElementById('lobby-screen').classList.contains('active')) {
      showLobbyMessage('join-room-message', friendly, 'error');
    }
  }

  function handleRoomJoined(payload) {
    enterGame(payload);
  }

  function handleSnapshotMsg(payload) {
    if (payload.board) {
      applySnapshot(payload);
    } else if (payload.snapshot) {
      applySnapshot(payload.snapshot);
    }
    updateGameUI();
  }

  function handleMoveRequested(payload) {
    if (!payload.accepted || !payload.motion) return;
    game.elapsedTimeMs = payload.elapsed_time_ms || game.elapsedTimeMs;
    addOrUpdateMotion(payload.motion);
  }

  function handleMoveResolved(payload) {
    game.elapsedTimeMs = payload.elapsed_time_ms || game.elapsedTimeMs;
    removeMotionByOrder(payload.motion ? payload.motion.order : -1);

    if (payload.piece && payload.final_position && game.board) {
      var src = payload.motion ? payload.motion.source : null;
      var movingPiece = null;

      if (src) {
        var idx = game.board.pieces.findIndex(function (p) {
          return p.cell.row === src.row && p.cell.col === src.col;
        });
        if (idx >= 0) {
          movingPiece = game.board.pieces[idx];
          game.board.pieces.splice(idx, 1);
        }
      }

      if (payload.captured) {
        var capCell = payload.captured.cell;
        var capIdx = game.board.pieces.findIndex(function (p) {
          return p.cell.row === capCell.row && p.cell.col === capCell.col;
        });
        if (capIdx >= 0) {
          game.board.pieces.splice(capIdx, 1);
        }
      }

      var finalPiece = payload.piece;
      var finalPos = payload.final_position;
      var existIdx = game.board.pieces.findIndex(function (p) {
        return p.cell.row === finalPos.row && p.cell.col === finalPos.col;
      });
      if (existIdx >= 0) {
        game.board.pieces.splice(existIdx, 1);
      }
      game.board.pieces.push({
        id: finalPiece.id,
        color: finalPiece.color,
        kind: finalPiece.kind,
        cell: finalPos,
      });
    }

    if (payload.players) {
      game.players = payload.players;
    }
    game.gameOver = payload.game_over || false;
    game.winnerColor = payload.winner_color || null;

    if (payload.notation) {
      game.moveLog.push({
        color: payload.piece ? payload.piece.color : '',
        time: formatTimeMs(game.elapsedTimeMs),
        notation: payload.notation,
      });
    } else if (movingPiece && payload.motion) {
      var notation = buildNotation(movingPiece, payload.motion.source, payload.motion.destination, payload.captured);
      game.moveLog.push({
        color: movingPiece.color,
        time: formatTimeMs(game.elapsedTimeMs),
        notation: notation,
      });
    }

    game.selected = null;
    updateGameUI();
  }

  function handleGameOverMsg(payload) {
    game.gameOver = true;
    game.winnerColor = payload.winner_color || null;
    updateGameUI();
  }

  function handlePlayerJoined(payload) {
    var color = payload.color;
    if (color && !game.players[color]) {
      game.players[color] = { name: payload.username, score: 0 };
    } else if (color && game.players[color]) {
      game.players[color].name = payload.username;
    }
    updateGameUI();
  }

  function handlePlayerLeft(payload) {
    var color = payload.color;
    if (color && game.players[color]) {
      game.players[color].name = null;
    }
    updateGameUI();
  }

  function handleMoveAck(payload) {
    if (!payload.accepted) {
      game.selected = null;
    }
  }

  /* ================================================================
     MOTION HELPERS
     ================================================================ */
  function addOrUpdateMotion(motionData) {
    removeMotionByOrder(motionData.order);
    game.motions.push(motionData);
  }

  function removeMotionByOrder(order) {
    game.motions = game.motions.filter(function (m) { return m.order !== order; });
  }

  function getMotionForCell(row, col) {
    for (var i = 0; i < game.motions.length; i++) {
      var m = game.motions[i];
      if (m.finish_time_ms && game.elapsedTimeMs >= m.finish_time_ms) continue;
      if (m.start_time_ms && game.elapsedTimeMs < m.start_time_ms) continue;

      var progress = 0;
      if (m.duration_ms > 0) {
        var elapsed = game.elapsedTimeMs - (m.start_time_ms || 0);
        progress = Math.min(Math.max(elapsed / m.duration_ms, 0), 1);
      }

      var srcR = m.source.row, srcC = m.source.col;
      var dstR = m.destination.row, dstC = m.destination.col;
      var curR = srcR + (dstR - srcR) * progress;
      var curC = srcC + (dstC - srcC) * progress;

      if (Math.round(curR) === row && Math.round(curC) === col) {
        return { progress: progress, motion: m };
      }
    }
    return null;
  }

  /* ================================================================
     BOARD INTERACTION
     ================================================================ */
  function onBoardClick(e) {
    if (game.gameOver) return;
    if (!game.board) return;

    var canvas = e.target;
    var rect = canvas.getBoundingClientRect();
    var x = e.clientX - rect.left;
    var y = e.clientY - rect.top;

    var col = Math.floor(x / CELL_SIZE);
    var row = Math.floor(y / CELL_SIZE);

    if (row < 0 || row >= 8 || col < 0 || col >= 8) return;

    if (session.role === 'observer') return;

    if (game.selected === null) {
      var piece = findPiece(row, col);
      if (!piece) return;
      if (piece.color !== session.color) return;
      game.selected = { row: row, col: col };
    } else {
      if (game.selected.row === row && game.selected.col === col) {
        game.selected = null;
        return;
      }
      var targetPiece = findPiece(row, col);
      if (targetPiece && targetPiece.color === session.color) {
        game.selected = { row: row, col: col };
        return;
      }

      wsSend({
        type: 'move',
        source: { row: game.selected.row, col: game.selected.col },
        destination: { row: row, col: col },
      });
      game.selected = null;
    }
  }

  function findPiece(row, col) {
    if (!game.board || !game.board.pieces) return null;
    for (var i = 0; i < game.board.pieces.length; i++) {
      var p = game.board.pieces[i];
      if (p.cell.row === row && p.cell.col === col) return p;
    }
    return null;
  }

  /* ================================================================
     CANVAS RENDERING
     ================================================================ */
  function startGameLoop() {
    if (gameAnimFrame) cancelAnimationFrame(gameAnimFrame);
    function loop() {
      game.animationTick++;
      game.elapsedTimeMs += 16;
      updateGameUI();
      drawBoard();
      gameAnimFrame = requestAnimationFrame(loop);
    }
    gameAnimFrame = requestAnimationFrame(loop);
  }

  function stopGameLoop() {
    if (gameAnimFrame) {
      cancelAnimationFrame(gameAnimFrame);
      gameAnimFrame = null;
    }
  }

  function drawBoard() {
    var canvas = document.getElementById('chess-canvas');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');

    for (var r = 0; r < 8; r++) {
      for (var c = 0; c < 8; c++) {
        var x = c * CELL_SIZE;
        var y = r * CELL_SIZE;
        ctx.fillStyle = (r + c) % 2 === 0 ? LIGHT_SQ : DARK_SQ;
        ctx.fillRect(x, y, CELL_SIZE, CELL_SIZE);
      }
    }

    if (game.selected) {
      ctx.fillStyle = SELECTED_COLOR;
      ctx.fillRect(game.selected.col * CELL_SIZE, game.selected.row * CELL_SIZE, CELL_SIZE, CELL_SIZE);
    }

    if (game.board && game.board.pieces) {
      game.board.pieces.forEach(function (piece) {
        var r = piece.cell.row;
        var c = piece.cell.col;

        var motionInfo = getMotionForCell(r, c);
        var drawRow = r;
        var drawCol = c;
        if (motionInfo) {
          var m = motionInfo.motion;
          var progress = motionInfo.progress;
          drawRow = m.source.row + (m.destination.row - m.source.row) * progress;
          drawCol = m.source.col + (m.destination.col - m.source.col) * progress;
        }

        drawPiece(ctx, piece, drawRow, drawCol);
      });
    }

    drawCoordinates(ctx);
  }

  function drawPiece(ctx, piece, row, col) {
    var x = col * CELL_SIZE + CELL_SIZE / 2;
    var y = row * CELL_SIZE + CELL_SIZE / 2;

    var unicode = PIECE_UNICODE[piece.color] && PIECE_UNICODE[piece.color][piece.kind];
    if (!unicode) return;

    ctx.font = '52px serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    if (piece.color === 'black') {
      ctx.fillStyle = '#000';
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 1.5;
      ctx.strokeText(unicode, x, y + 2);
      ctx.fillText(unicode, x, y + 2);
    } else {
      ctx.fillStyle = '#fff';
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 1.5;
      ctx.strokeText(unicode, x, y + 2);
      ctx.fillText(unicode, x, y + 2);
    }
  }

  function drawCoordinates(ctx) {
    ctx.font = '11px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';
    var files = 'abcdefgh';
    for (var c = 0; c < 8; c++) {
      var isLight = (7 + c) % 2 === 0;
      ctx.fillStyle = isLight ? DARK_SQ : LIGHT_SQ;
      ctx.fillText(files[c], c * CELL_SIZE + CELL_SIZE - 6, 8 * CELL_SIZE - 2);
    }
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    for (var r = 0; r < 8; r++) {
      var isLightRow = (r + 0) % 2 === 0;
      ctx.fillStyle = isLightRow ? DARK_SQ : LIGHT_SQ;
      ctx.fillText(String(8 - r), 3, r * CELL_SIZE + 2);
    }
  }

  /* ================================================================
     NOTATION HELPERS
     ================================================================ */
  function buildNotation(piece, src, dst, captured) {
    var files = 'abcdefgh';
    var srcStr = files[src.col] + (8 - src.row);
    var dstStr = files[dst.col] + (8 - dst.row);
    var prefix = pieceKindLetter(piece.kind);
    var capture = captured ? 'x' : '';
    return prefix + srcStr + capture + dstStr;
  }

  function pieceKindLetter(kind) {
    var map = { king: 'K', queen: 'Q', rook: 'R', bishop: 'B', knight: 'N', pawn: '' };
    return map[kind] || '';
  }

  function formatTimeMs(ms) {
    var totalSec = Math.floor(ms / 1000);
    var mins = Math.floor(totalSec / 60);
    var secs = totalSec % 60;
    return String(mins).padStart(2, '0') + ':' + String(secs).padStart(2, '0');
  }

  /* ================================================================
     REASON FORMATTING
     ================================================================ */
  function formatReason(reason) {
    var map = {
      'invalid_credentials': 'Invalid username or password',
      'user_already_exists': 'Username already taken',
      'username_required': 'Username is required',
      'room_not_found': 'Room not found',
      'room_full': 'Room is full',
      'invalid_room_name': 'Invalid room name',
      'login_required': 'Please login first',
      'invalid_json': 'Invalid message',
      'unknown_message_type': 'Unknown message type',
      'invalid_move_payload': 'Invalid move',
      'observer_read_only': 'Observers cannot make moves',
      'empty_source': 'No piece at source',
      'wrong_player_color': 'Not your piece',
      'piece_in_flight': 'Piece is in motion',
      'game_over': 'Game is over',
    };
    return map[reason] || reason;
  }

  function escapeHtml(text) {
    if (!text) return '';
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  /* ================================================================
     INIT
     ================================================================ */
  function init() {
    setupAuth();
    setupLobby();
    setupGame();
    onMessage(handleServerMessage);
    connectWS();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
